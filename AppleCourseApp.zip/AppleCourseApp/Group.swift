import Foundation
import CoreData

@objc(Group)
class Group: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var course: Int32
    @NSManaged var students: NSSet

    override class func entity() -> NSEntityDescription {
        return NSEntityDescription.entity(forEntityName: "Group", in: CoreDataHelper.instance.context)!
    } // newest
    
    
    convenience init() {
        self.init(entity: Group.entity(), insertInto: CoreDataHelper.instance.context)
    }
    
    class func groupsCount() -> Int {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Group")
        
        do {
            let results = try CoreDataHelper.instance.context.fetch(fetchRequest)
            return results.count
        } catch {
            return 0
        }
    }

    
    class func sharedGroup() -> Group {
        let group: Group
        
        if Group.groupsCount() == 0 {
            group = Group()
            group.name = "172"
            group.course = 1
        } else {
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Group")
            request.fetchLimit = 1
            group = (try! CoreDataHelper.instance.context
                .fetch(request)).first as! Group
        }
        
        return group
    }
}
