import UIKit

class StudentsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, NewStudentViewControllerDelegate {

//    students - didLoad
//    students - willAppear
//    students - didAppear
    
    
    @IBOutlet weak var tableStudents: UITableView!
    
    //сихнронно (в Main/UI потоке) получить
//    var students = Student.allStudents()
    var students = [Student]()
    
    let operationQueue = OperationQueue()
    
    deinit {
        print("students - deinit")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //1: GCD
        //DISPATCH_QUEUE_PRIORITY_BACKGROUND
        //DISPATCH_QUEUE_PRIORITY_LOW
        //DISPATCH_QUEUE_PRIORITY_DEFAULT
        //DISPATCH_QUEUE_PRIORITY_HIGH

// old
//        let queue = DispatchQueue.global(
//            priority: DispatchQueue.GlobalQueuePriority.background)
//        //асинхронное выполнение
//        queue.async(execute: {
//            sleep(5)
//        })

        
        
// new
//        .background
//        .utility
//        .default
//        .userInitiated
//        .userInteractive
//        .unspecified
        DispatchQueue.global(qos: .background).async { //асинхронное выполнение
            sleep(5)
        }

        
        //2: NSOperationQueue
        //кол-во одновременных задач
        operationQueue.maxConcurrentOperationCount = 5
        operationQueue.addOperation({
            sleep(5)
        })
        
        
        //сказать таблице, что мы подаем данные
        //необходимо реализовать UITableViewDataSource протокол
        //в заголовке класса
        tableStudents.dataSource = self
        tableStudents.delegate = self  //реализовать UITableViewDelegate
        
        print("students - didLoad")
        
        //создать pull-to-refresh
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(StudentsViewController.refresh(_:)), for: .valueChanged)
        tableStudents.addSubview(refreshControl)
    }
    
    func refresh(_ refreshControl: UIRefreshControl?) {
        Student.fetchStudentsWithCompletion { students in
            self.reloadStudents()
            
            refreshControl?.endRefreshing()
        }
    }
    
    //прямо перед показом представления (view)
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        print("students - willAppear")
        
        reloadStudents()
        
        //асинхронно загрузить с сервера
        refresh(nil)
    }
    
    func reloadStudents() {
        //грузим [Student] асинхронно
        Student.allStudentsWithCompletionHandler({ students in
            self.students = students
            self.tableStudents.reloadData()
        })
    }
    
    //аналогично, но уже показался
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        print("students - didAppear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        print("students - willDisappear")
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        print("students - didDisappear")
    }

    //выдать количество ячеек
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return students.count
    }
    
    //сконфигурировать ячейку по indexPath (.row, .section)
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //достать ячейку из кеша
        let cell = tableView.dequeueReusableCell(
            withIdentifier: "StudentTableViewCell") as! StudentTableViewCell
        
        //конфигурируем ячейку
        let student = students[indexPath.row]
        
        cell.labelName.text = student.name
        cell.roundGrade.grade = Int(student.grade)
        
        return cell
    }
    
    //можно ли редактировать ячейки
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    //как можно их редактировать
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return .delete
    }
    
    //применить редактирование
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        //удаление ячейки + удаление из модели
        tableView.beginUpdates()
        
        tableView.deleteRows(at: [indexPath],
            with: UITableViewRowAnimation.left)
        
        let student = students[indexPath.row]
        students.remove(at: indexPath.row)
        CoreDataHelper.instance.context.delete(student)
        do {
            try CoreDataHelper.instance.context.save()
        } catch _ {
        }
        
        //завершить обновление
        tableView.endUpdates()
    }
    
    //выбрал ячейку
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print("selected row at \(indexPath.row)")
        
        //убрать выделение с анимацией
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let controller = segue.destination as? UINavigationController
        
        if let newStudentController = controller?.viewControllers.first as? NewStudentViewController {
            
            newStudentController.delegate = self
            
        }
    }
    
    func newStudentController(_ controller: NewStudentViewController, createdStudentWithName name: String, grade: Int) {
        
        let student = Student(name: name, grade: grade)
        student.group = Group.sharedGroup()
        students.append(student)
        
        student.saveOnServer()
        
        do {
            try CoreDataHelper.instance.context.save()
        } catch _ {
        }
        
        //попросить таблицу обновить данные
        //вызовется numberOfRows..., cellForRow...
        tableStudents.reloadData()
        
        //убрать текущий модальный контроллер
        dismiss(animated: true, completion: nil)
    }
}
