import UIKit
import CoreData
import Foundation

let StudentSession = URLSession(configuration:
    URLSessionConfiguration.default)

//@objc нужно для правильной работы CoreData
@objc(Student)
class Student: NSManagedObject {
    @NSManaged var name: String
    @NSManaged var grade: Int16
    @NSManaged var group: Group
    @NSManaged var studentID: String
    
    override class func entity() -> NSEntityDescription {
        return NSEntityDescription.entity(forEntityName: "Student", in: CoreDataHelper.instance.context)!
    }
    

    convenience init() {
        self.init(entity: Student.entity(), insertInto: CoreDataHelper.instance.context)
    }

    
    convenience init(name: String, grade: Int) {
        self.init()
        self.name = name
        self.grade = Int16(grade)
    }
    
    
    class func allStudents() -> [Student] {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        fetchRequest.sortDescriptors = [
            NSSortDescriptor(key: "grade", ascending: true)
        ]
        
        let results = try? CoreDataHelper.instance.context.fetch(
            fetchRequest)
        
        return results as! [Student]
    }

    
    // This method is for asynchronous work!
    class func allStudentsWithCompletionHandler(
        _ completion: @escaping ([Student]) -> Void) {
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
            fetchRequest.sortDescriptors = [
                NSSortDescriptor(key: "grade", ascending: true)
            ]
            
            // This performBlock garanties an implementation on a thread of context!
            CoreDataHelper.instance.backgroundContext.perform({

                // Here we are working asynchronously!
                fetchRequest.resultType = .managedObjectIDResultType
                
                // Getting ID of objects
                let ids = (try! CoreDataHelper.instance.backgroundContext.fetch(fetchRequest)) as! [NSManagedObjectID]
                
                // Invocation to the main context!
                CoreDataHelper.instance.context.perform({
                    // Here we are working asynchronously also!
                    var objects = [Student]()
                    for id in ids {
                        let object = CoreDataHelper.instance.context.object(with: id)
                        objects.append(object as! Student)
                    }
                    completion(objects)
                })
            })
    }
    

    class func studentWithID(_ id: String) -> Student? {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Student")
        fetchRequest.predicate = NSPredicate(format: "studentID == %@", id)
        
        var i = 0
        for _ in 0...1_000 {
            i += 1
        }
        
        let results = try? CoreDataHelper.instance.context.fetch(
            fetchRequest)
        
        return results?.first as? Student
    }
    
    class func fetchStudentsWithCompletion(_ completion: @escaping ([Student]) -> Void) {
        //let url = URL(string:
          //  "http://dev-pronin.appspot.com/api/swift/students")!

        let url = URL(string: "http://0.0.0.0:8080/students")!
        
        
        
        //GET запрос
        let task = StudentSession.dataTask(with: url, completionHandler: { (data, response, error) in

            // Here we are working in a task flow (asynchronously)!
            if error != nil {
                print(error!.localizedDescription)
            } else {
                let json = (try! JSONSerialization.jsonObject(with: data!, options: [])) as! [String: AnyObject]
                
                let jsonStudents = json["students"] as!
                    [ [String: AnyObject] ]

//                print(jsonStudents)
                
                // Here we are going in main flow
                OperationQueue.main.addOperation({
                    var students = [Student]()
                    for jsonStudent in jsonStudents {
                        
//                        print(jsonStudent)
                        
                        
                        let studentID = jsonStudent["id"] as! String
                        let student =
                            Student.studentWithID(studentID) ?? Student()
                        
                        student.name = jsonStudent["Name"] as! String
                        student.grade = Int16(jsonStudent["grade"] as! Int)
                        student.studentID = jsonStudent["id"] as! String

                        print()
                        print(student.name)
                        print(student.grade)
                        print(student.studentID)
                        print()
                        
                        students.append(student)
                    }
                    do {
                        try CoreDataHelper.instance.context.save()
                    } catch _ {
                    }
                    completion(students)
                })
            }
        }) 
        task.resume()
    }
    
    
    func saveOnServer() {
        
        // distant server
        let url = URL(string:
            "http://dev-pronin.appspot.com/api/swift/students")!

        // local server
//        let url = URL(string:
//            "http://localhost:8080/students")!
        
        
        var request = URLRequest(url: url) // new
        
        request.httpMethod = "POST"
        
        let unreserved = "-._~/?"
        let allowed = NSMutableCharacterSet.alphanumeric()
        allowed.addCharacters(in: unreserved)
// ??? name
        
        let grade = self.grade.description
        let body = "name=\(name)&grade=\(grade)"
        request.httpBody = body.data(using: String.Encoding.utf8)
        
        print("!!!")
//        print(body)
//        print(request.httpBody)
        print("!!!!!!")
        
        
        let task = StudentSession.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            
            if error != nil {
                print(error!.localizedDescription)
            } else {
        
                let json = (try! JSONSerialization.jsonObject(with: data!, options: [])) as! [String: AnyObject]
            
                let jsonStudent = json["student"] as! [String: AnyObject]
            
//              Here we are going into main flow!
                OperationQueue.main.addOperation({
                    self.studentID = jsonStudent["id"] as! String
                    do {
                        try CoreDataHelper.instance.context.save()
                    } catch _ { }
                    print("saved")
                })
            }
        })

        task.resume()
    }
}

