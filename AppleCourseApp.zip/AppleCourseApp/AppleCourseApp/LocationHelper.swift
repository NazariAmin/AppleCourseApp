import UIKit
import CoreLocation

class LocationHelper: NSObject, CLLocationManagerDelegate {
    class var instance: LocationHelper {
        struct Singleton {
            static let instance = LocationHelper()
        }
        return Singleton.instance
    }
    
    let locationManager: CLLocationManager
    
    var completion: ((CLLocation) -> Void)?
    
    fileprivate override init() {
        locationManager = CLLocationManager()
        super.init()
        
        //указать в заголовке реализацию протокола CLLocationManagerDelegate
        locationManager.delegate = self
    }
    
    func acquireLocation(_ completion: ((CLLocation) -> Void)?) {
        self.completion = completion
        requestAuthorization()
    }
    
    func requestAuthorization() {
        switch CLLocationManager.authorizationStatus() {
            case .notDetermined:
                locationManager.requestWhenInUseAuthorization()
            case .authorizedAlways:
                fallthrough
            case .authorizedWhenInUse:
                locationManager.startUpdatingLocation()
            default:
                print("сказать пользователю включить доступ в Настройках")
        }
    }
    
    //CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            locationManager.startUpdatingLocation()
        } else if status != .notDetermined {
            print("сказать пользователю включить доступ в Настройках")
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.first
        
        completion?(location!)
        
        print("локация: \(location!.coordinate.latitude), \(location!.coordinate.longitude)")
        
        locationManager.stopUpdatingLocation()
    }
}
