import UIKit

class RoundLabel: UIView {
    
    var grade: Int = 0 {
        didSet {
            setNeedsDisplay()
        }
    }

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        //фон
        //поставить текущий цвет заполнения в серый
        UIColor.darkGray.setFill()
        
        let oval = UIBezierPath(ovalIn: rect)
        //заполнить текущим цветом заполнения
        oval.fill()
        
        //текст
        let string = grade.description
        
        let attributes = [
            NSForegroundColorAttributeName: UIColor.white,
            NSFontAttributeName: UIFont(name: "HelveticaNeue", size: 14)!
        ]
        
        //подсчет размера строки
        let stringSize = (string as NSString).boundingRect(
            with: CGSize(width: 500, height: 500),
            options: [],
            attributes: attributes,
            context: nil).size
        
        //позиционирование прямоугольника для строки
        let stringRect = CGRect(x: (rect.width - stringSize.width)/2,
            y: (rect.height - stringSize.height)/2,
            width: stringSize.width,
            height: stringSize.height)
        
        (string as NSString).draw(in: stringRect,
            withAttributes: attributes)
    }
    
    //вернуть размер по контенту
//    override func intrinsicContentSize() -> CGSize {
//        
//    }
}
