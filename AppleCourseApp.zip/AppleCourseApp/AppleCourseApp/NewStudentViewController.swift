import UIKit

//способ передачи информации обратно
protocol NewStudentViewControllerDelegate: NSObjectProtocol {
    //"событие"
    func newStudentController(_ controller: NewStudentViewController, createdStudentWithName name: String, grade: Int)
}

class NewStudentViewController: UIViewController, UITextFieldDelegate
{
    
    let imageView = UIImageView()
    
    
    @IBOutlet weak var textFieldName: UITextField!
    @IBOutlet weak var textFieldGrade: UITextField!
    
    weak var delegate: NewStudentViewControllerDelegate?

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        textFieldName.delegate = self
        
        //добавляем распознаватель, чтобы убирать клавиатуру по нажатию
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(NewStudentViewController.tapView(_:)))
        self.view.addGestureRecognizer(recognizer)
        self.view.isUserInteractionEnabled = true
        
/////////
        
        LocationHelper.instance.acquireLocation { location in
            print("локация \(location)")
        }
        
        let image = UIImage(named: "space.jpg")!
        
        imageView.image = image
        
        imageView.frame = self.view.bounds
        imageView.contentMode = UIViewContentMode.scaleAspectFill
        
        //добавить поверх всех
        //self.view.addSubview(imageView)
        self.view.insertSubview(imageView, at: 0)
        
        //        var converter = AudioConverter()
        //[[AudioConverter alloc] init]
        //[AudioConverter new]
        
        
        let date = Date()  //текущая дата и время
        
        //вывод даты
        let formatter = DateFormatter()
        formatter.dateStyle = DateFormatter.Style.none
        formatter.timeStyle = DateFormatter.Style.short
        let stringDate = formatter.string(from: date)
        print(stringDate)
        
        
        //из строки в дату
        let parser = DateFormatter()
        parser.dateFormat = "yyyy-MM-dd HH:mm"
        let parsedDate = parser.date(from: "2015-05-28 15:36")!
        
        print(formatter.string(from: parsedDate))
    }
    
    func tapView(_ recognizer: UITapGestureRecognizer) {
        //если жест закончен (палец оторвали от экрана)
        if recognizer.state == UIGestureRecognizerState.ended {
            //закрываем клавиатуру, убирая фокус
            textFieldName.resignFirstResponder()
            textFieldGrade.resignFirstResponder()
        }
    }
    
    
    @IBAction func tapCancel(_ sender: AnyObject) {
        //presentingViewController тот, кто нас показывает
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func tapSave(_ sender: AnyObject) {
        let name = textFieldName.text
        let grade = Int(textFieldGrade.text!)
        
        if name!.characters.count == 0 {
            textFieldName.backgroundColor = UIColor.orange
        } else {
            textFieldName.backgroundColor = UIColor.white
        }
        
        if grade == nil {
            textFieldGrade.backgroundColor = UIColor.orange
        } else {
            textFieldGrade.backgroundColor = UIColor.white
        }
        
        if grade != nil && name!.characters.count > 0 {
            delegate?.newStudentController(self, createdStudentWithName: name!, grade: grade!)
        }
    }
    
    //вызывается на ввод каждого символа
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        textFieldName.backgroundColor = UIColor.white
        
        return true
    }
    
    //в этот момент пользователь нажал на Enter (Next)
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //отдать фокус, опустить клавиатуру в случае textField
        //textFieldName.resignFirstResponder()
        
        //получить фокус
        textFieldGrade.becomeFirstResponder()
        
        return false
    }
    
///  
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 1,
                       animations: {
                        var frame = self.imageView.frame
                        frame.size.width /= 2
                        frame.size.height /= 2
                        self.imageView.frame = frame
        },
                       completion: { finished in
                        //finished false если анимация была прервана
                        //finished true если анимация успешно закончилась
                        print("animation ended")
        })
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        imageView.frame = self.view.bounds
        
    }
    
    /*
     let alert = UIAlertController(title: "Успешно!",
     message: "Результат получен!",
     preferredStyle: UIAlertControllerStyle.alert)
     alert.addAction(UIAlertAction(title: "OK",
     style: UIAlertActionStyle.default,
     handler: { action in
     print("ok clicked")
     }))
     present(alert, animated: true, completion: nil)
     */
    
}


